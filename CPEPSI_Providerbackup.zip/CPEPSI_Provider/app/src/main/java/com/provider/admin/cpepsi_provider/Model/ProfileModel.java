package com.provider.admin.cpepsi_provider.Model;

public class ProfileModel {

    private String image;

    public ProfileModel(String image) {
        this.image = image;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }


}
